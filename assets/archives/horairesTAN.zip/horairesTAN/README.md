# Horaires TAN

Auteur : Maverick Chardet  
Licence : WTFPL  
Site : https://github.com/chardetm/horairesTAN

## Crédits

Thèmes Bootstrap : https://bootswatch.com/
- Flatly : https://bootswatch.com/flatly/
- Darkly : https://bootswatch.com/darkly/

Ensemble d'icônes : https://fontawesome.com/
