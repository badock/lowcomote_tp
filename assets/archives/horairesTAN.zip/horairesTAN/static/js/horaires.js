// Partie 1 : thème sombre

// à compléter


// Partie 2 : chargement de la liste des arrêts

// à compléter


// Partie 3 : chargement des horaires d'un arrêt

// à compléter

// Fonction déjà fournie
function directionHtml(details_direction) {
    let dictionnaire_terminus = details_direction["terminus"];
    let liste_terminus = Object.keys(dictionnaire_terminus);
    let terminus_string = liste_terminus[0];
    if (liste_terminus.length > 1) {
        terminus_string = Object.entries(dictionnaire_terminus).map(pair => `${pair[0]} (${pair[1]})`).join(" / ");
    }

    let direction_html = `<div class="direction">
                              <h3 class="card-title">${terminus_string}</h3>
                              <ul class="passages">`;
    for (let passage of details_direction["passages"].slice(0,10)) {
        if (liste_terminus.length > 1) {
            direction_html += `<li>${passage["temps"]} (${passage["no_terminus"]})</li>`;
        } else {
            direction_html += `<li>${passage["temps"]}</li>`;
        }
    }
    direction_html += `</ul></div>`;
    return direction_html;
}
